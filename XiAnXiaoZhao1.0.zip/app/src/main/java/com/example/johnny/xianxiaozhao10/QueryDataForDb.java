package com.example.johnny.xianxiaozhao10;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.List;

/**
 * Created by johnny on 2016/3/5.
 */
public class QueryDataForDb {
    private MyDatabaseHelper dbHelper;
    private Context activity;
    private List<Job> jobList;
    public QueryDataForDb(Context activity,List<Job> jobList){
        this.activity = activity;
        this.jobList = jobList;
        query();
    }
    public void query() {
        dbHelper = new MyDatabaseHelper(activity);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Cursor cursor = db.query(MyDatabaseHelper.TABLENAME, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                String companyName = cursor.getString(cursor.getColumnIndex(MyDatabaseHelper.COMPANYNAME));
                String situsName = cursor.getString(cursor.getColumnIndex(MyDatabaseHelper.SITUSNAME));
                String time = cursor.getString(cursor.getColumnIndex(MyDatabaseHelper.TIME));
                String id = cursor.getString(cursor.getColumnIndex(MyDatabaseHelper.JOBID));
                String schoolName = cursor.getString(cursor.getColumnIndex(MyDatabaseHelper.SCHOOLNAME));
                Job job = new Job(companyName, situsName, time, id,schoolName);
                jobList.add(job);
            } while (cursor.moveToNext());
            cursor.close();
        }
    }}
