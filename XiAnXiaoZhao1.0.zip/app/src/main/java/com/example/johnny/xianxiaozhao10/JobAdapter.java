package com.example.johnny.xianxiaozhao10;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by johnny on 2016/3/1.
 */
//自定义jobAdapter
public class JobAdapter extends ArrayAdapter<Job> {
    private int resourceId;
    public JobAdapter(Context context,int textViewResourceId, List<Job> objects) {
        super(context,textViewResourceId, objects);
        resourceId = textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Job job = getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView == null){
            view = LayoutInflater.from(getContext()).inflate(resourceId,null);
            viewHolder = new ViewHolder();
            viewHolder.companyName = (TextView) view.findViewById(R.id.companyName);
            viewHolder.situsName = (TextView) view.findViewById(R.id.situsName);
            viewHolder.time = (TextView) view.findViewById(R.id.tm);
            view.setTag(viewHolder);
        }else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.companyName.setText(job.getCompanyName());
        viewHolder.situsName.setText(job.getSitusName());
        viewHolder.time.setText(job.getTime());
//        设置listview隔行变色
        if (position % 2 == 0){
            view.setBackgroundColor(Color.parseColor("#EEEEEE"));
        }else {
            view.setBackgroundColor(Color.parseColor("#FBFBFB"));
        }
        return view;
    }
    class ViewHolder{
        TextView companyName;
        TextView situsName;
        TextView time;
    }
}


