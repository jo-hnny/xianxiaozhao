package com.example.johnny.xianxiaozhao10;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by johnny on 2016/3/5.
 */
public class AddDataToDb {
    private String companyName;
    private String situsName;
    private String time;
    private String id;
    private String schoolName;
    private Context activity;
    private MyDatabaseHelper dbHelper;
    public AddDataToDb(Context activity,String companyName,String situsName,String time,String id,String schoolName){
        this.activity =activity;
        this.companyName = companyName;
        this.situsName = situsName;
        this.time = time;
        this.id = id;
        this.schoolName =schoolName;
        add();
    }
    public void  add(){
        dbHelper = new MyDatabaseHelper(activity);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(MyDatabaseHelper.COMPANYNAME,companyName);
        values.put(MyDatabaseHelper.SITUSNAME,situsName);
        values.put(MyDatabaseHelper.TIME,time);
        values.put(MyDatabaseHelper.JOBID,id);
        values.put(MyDatabaseHelper.SCHOOLNAME,schoolName);
        db.insert(MyDatabaseHelper.TABLENAME, null, values);
        values.clear();
    }
}
