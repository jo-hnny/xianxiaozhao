package com.example.johnny.xianxiaozhao10;

import java.util.List;

/**
 * Created by johnny on 2016/3/2.
 */
//接受从Mainfragment得到的网页数据然后分配给不同的类处理；
public class InitJobList {
    private List<Job> jobList;
    private int schoolId;
    private String httpData;
    public InitJobList(List<Job> jobList,int schoolId,String httpData){
        this.jobList = jobList;
        this.schoolId = schoolId;
        this.httpData = httpData;
        selected();
    }
    public void selected(){
       switch (schoolId){
           case R.id.xiankejidaxue:
           case R.id.xianjianzhukejidaxue:
           case R.id.changandaxue:
           case R.id.xiangongchengdaxue:
           case R.id.xibeinonglinkejidaxue:
               new ParseJson(httpData,jobList,schoolId);
               break;
           case R.id.xianjiaotongdaxue:
               new ParseXAJDHttpData(httpData,jobList);
               break;
           case R.id.xibeigongyedaxue:
               new ParseXBGYHttpData(httpData,jobList);

       }
    }
}
