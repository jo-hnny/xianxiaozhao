package com.example.johnny.xianxiaozhao10;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by johnny on 2016/3/5.
 */
//使用正则表达式解析西安交通大学的网页数据；
public class ParseXAJDHttpData {
    private String httpData;
    private List<Job> jobList;
    private final String schoolName = "西安交通大学";
    private final String regex1 = "<th colspan=\"3\" class=\"week_fairs_title\">(.*?)</th>(.*?)</table>";
    private final String regex2 =
            "href=\"(.*?)\".*?target=\"_blank\" title=\"(.*?)\">.*?<td width=\"30%\">(.*?)</td>.*?<td width=\"17%\">.*?([0-9]{2}:[0-9]{2}-).*?([0-9]{2}:[0-9]{2})";
    public ParseXAJDHttpData(String httpData,List<Job> jobList){
        this.httpData = httpData;
        this.jobList = jobList;
        parseHttpData();
    }
    public void parseHttpData(){
        Pattern p1 = Pattern.compile(regex1);
        Matcher m1 = p1.matcher(httpData);
        while (m1.find()){
            Pattern p2 = Pattern.compile(regex2);
            Matcher m2 = p2.matcher(m1.group(2));
            while (m2.find()){
                Job job = new Job(m2.group(2),schoolName+m2.group(3),m1.group(1)+m2.group(4)+m2.group(5),m2.group(1),schoolName);
                jobList.add(job);
            }
        }
    }
}
