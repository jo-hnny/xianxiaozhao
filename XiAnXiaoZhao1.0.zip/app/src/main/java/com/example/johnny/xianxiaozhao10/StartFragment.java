package com.example.johnny.xianxiaozhao10;

import android.os.Bundle;

/**
 * Created by johnny on 2016/3/6.
 */
public class StartFragment {
    private int schoolId;
    private MainActivity activity;
    public StartFragment(MainActivity activity,int schoolId){
        this.activity = activity;
        this.schoolId = schoolId;
        startFragment();
    }
    public void startFragment( ){
        MainFragment mainFragment = new MainFragment();
        Bundle bundle = new Bundle();
        bundle.putInt("SCHOOLID", schoolId);
        mainFragment.setArguments(bundle);
        activity.getFragmentManager().beginTransaction().replace(R.id.fl,mainFragment).commit();

    }

}
