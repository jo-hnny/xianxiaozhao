package com.example.johnny.xianxiaozhao10;

import android.os.Handler;
import android.os.Message;

/**
 * Created by johnny on 2016/3/3.
 */
//存储需要的常量信息，并且根据SCHOOLID给GetHttpData传入相应数据；
public class SelectSchool {
    private int schoolId;
    private Handler handler;
    private final String xiankejidaxueHttp =
            "http://202.200.48.160:8080/Frame/Data/jdp.ashx?rnd=1456733422935&fn=GetJobFairListToWeb&StartDate";
    private final String xianjianzhukejidaxueHttp =
            "http://jobsys.xauat.edu.cn/Frame/Data/jdp.ashx?rnd=1448531454901&fn=GetJobFairListToWeb&StartDate";
    private final String changandaxueHttp =
            "http://182.254.150.113:88/Frame/Data/jdp.ashx?rnd=1448531531751&fn=GetJobFairListToWeb&StartDate";
    private final String xianjiaotongdaxueHttp =
            "http://job.xjtu.edu.cn/listMeeting.do?is4practice=0";
    private final String xibeigongyedaxueHttp =
            "http://job.nwpu.edu.cn/listMeeting.do;jsessionid=34A27E8A9F231DD21CCEF736D83FD389";
    private final String xiangongchengdaxueHttp =
            "http://jobsys.xpu.edu.cn/Frame/Data/jdp.ashx?rnd=1457163723260&fn=GetJobFairListToWeb&StartDate";
    private final String xibeinonglinkejidaxueHttp =
            "http://jyglxt.nwsuaf.edu.cn/Frame/Data/jdp.ashx?rnd=1457165350122&fn=GetJobFairListToWeb&StartDate";
//    使用构造函数接受学校Id和Handler；
    public SelectSchool(int schoolId, Handler handler){
        this.schoolId = schoolId;
        this.handler = handler;
        selectSchool();
    }
//    给gethttpdata传入所选择学校的数据地址和handler；
    public void selectSchool(){
        switch (schoolId){
            case 0:
            case R.id.shoucang:
                Message msg = handler.obtainMessage(1);
                handler.sendMessage(msg);
                break;
            case R.id.xiankejidaxue:
                new GetHttpData(xiankejidaxueHttp,handler);
                break;
            case R.id.xianjianzhukejidaxue:
                new GetHttpData(xianjianzhukejidaxueHttp,handler);
                break;
            case R.id.changandaxue:
                new GetHttpData(changandaxueHttp,handler);
                break;
            case R.id.xianjiaotongdaxue:
                new GetHttpData(xianjiaotongdaxueHttp,handler);
                break;
            case R.id.xibeigongyedaxue:
                new GetHttpData(xibeigongyedaxueHttp,handler);
                break;
            case R.id.xiangongchengdaxue:
                new GetHttpData(xiangongchengdaxueHttp,handler);
                break;
            case R.id.xibeinonglinkejidaxue:
                new GetHttpData(xibeinonglinkejidaxueHttp,handler);
                break;
        }
    }
}
