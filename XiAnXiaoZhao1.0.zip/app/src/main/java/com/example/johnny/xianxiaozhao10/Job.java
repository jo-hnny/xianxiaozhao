package com.example.johnny.xianxiaozhao10;

/**
 * Created by johnny on 2016/3/1.
 */
//定义适配类型；
public class Job {
    private String companyName;
    private String situsName;
    private String time;
    private String id;
    private String schoolName;
    public Job(String companyName,String situsName,String time,String id,String schoolName){
        this.companyName = companyName;
        this.situsName = situsName;
        this.time = time;
        this.id = id;
        this.schoolName = schoolName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getSitusName() {
        return situsName;
    }

    public String getTime() {
        return time;
    }

    public String getId() {
        return id;
    }

    public String getSchoolName() {
        return schoolName;
    }
}
