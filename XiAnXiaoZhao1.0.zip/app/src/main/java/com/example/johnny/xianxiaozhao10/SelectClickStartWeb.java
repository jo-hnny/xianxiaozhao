package com.example.johnny.xianxiaozhao10;

import android.content.Intent;
import android.net.Uri;

/**
 * Created by johnny on 2016/3/6.
 */
public class SelectClickStartWeb {
    private String itemHttp;
    private final String xiankejidaxueHead =
            "http://202.200.48.160:8080/Pro_StudentEmploy/StudentJobFair/JobFairSingle_Detail.aspx?JobId=";
    private final String xianjianzhukejidaxueHead =
            "http://jobsys.xauat.edu.cn/Pro_StudentEmploy/StudentJobFair/JobFairSingle_Detail.aspx?JobId=";
    private final String changandaxueHead =
            "http://182.254.150.113:88/Pro_StudentEmploy/StudentJobFair/JobFairSingle_Detail.aspx?JobId=";
    private final  String xiangongchengdaxueHead =
            "http://jobsys.xpu.edu.cn/Pro_StudentEmploy/StudentJobFair/JobFairSingle_Detail.aspx?JobId=";
    private final String xibeinonglinkejidaxueHead =
            "http://jyglxt.nwsuaf.edu.cn/Pro_StudentEmploy/StudentJobFair/JobFairSingle_Detail.aspx?JobId=";
    private final String xibeigongyedaxueHead = "http://job.nwpu.edu.cn";
    private final String xianjiaotongdaxueHead = "http://job.xjtu.edu.cn";
    private String schooName;
    private String jobId;
    private MainActivity mainActivity;
    public SelectClickStartWeb(MainActivity mainActivity,String schoolName,String jobId){
        this.mainActivity = mainActivity;
        this.schooName = schoolName;
        this.jobId = jobId;
        select();
    }
    public void select(){
        switch (schooName) {
            case "西安科技大学":
                itemHttp = xiankejidaxueHead + jobId;
                startWeb();
                break;
            case "西安建筑科技大学":
                itemHttp = xianjianzhukejidaxueHead + jobId;
                startWeb();
                break;
            case "长安大学":
                itemHttp = changandaxueHead + jobId;
                startWeb();
                break;
            case "西安交通大学":
                if (jobId.substring(0,4).equals("http")){
                    itemHttp = jobId;
                }else {
                    itemHttp = xianjiaotongdaxueHead + jobId;
                }
                startWeb();
                break;
            case "西北工业大学":
                itemHttp = xibeigongyedaxueHead + jobId;
                startWeb();
                break;
            case "西安工程大学":
                itemHttp = xiangongchengdaxueHead + jobId;
                startWeb();
                break;
            case "西北农林科技大学":
                itemHttp = xibeinonglinkejidaxueHead + jobId;
                startWeb();
                break;
        }
    }
    public void startWeb(){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(itemHttp));
        mainActivity.startActivity(intent);
    }
}
