package com.example.johnny.xianxiaozhao10;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by johnny on 2016/3/5.
 */
//解析西北工业大学的网页数据
public class ParseXBGYHttpData {
    private String httpData;
    private List<Job> jobList;
    private final String schoolName = "西北工业大学";
    private final String regex =
            "<div class=\"timeline-time\">.*?<h2>(.*?)</h2>.*?时　　间：(.*?)<br/>.*?地　　点：(.*?)<br/>.*?href=\"(.*?)\"";
    public ParseXBGYHttpData(String httpData,List<Job> jobList) {
        this.httpData = httpData;
        this.jobList = jobList;
        parseHttpData();
    }
    public  void parseHttpData(){
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(httpData);
        while (m.find()){
            Job job = new Job(m.group(1),schoolName+m.group(3),m.group(2),m.group(4),schoolName);
            jobList.add(job);
        }
    }
}
