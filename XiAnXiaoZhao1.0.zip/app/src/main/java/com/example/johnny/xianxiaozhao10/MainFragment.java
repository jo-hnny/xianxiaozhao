package com.example.johnny.xianxiaozhao10;


import android.app.ListFragment;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainFragment extends ListFragment {
    private List<Job> jobList = new ArrayList<>();
    private String httpData;
    private int schoolid;
    private ProgressDialog progressDialog;
//    定义handler接受GetHttpData传递的网页数据
    private Handler handler =new Handler(){
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case  0 :
                    httpData = (String) msg.obj;
                    new InitJobList(jobList,schoolid,httpData);
                    progressDialog.dismiss();
                    break;
                case 1:
                    new QueryDataForDb(getActivity(),jobList);
                    break;
            }
            JobAdapter adapter = new JobAdapter(getActivity(),R.layout.job_item,jobList);
            setListAdapter(adapter);

        }
    };
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main,container,false);
        return view;


    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        schoolid = getArguments().getInt("SCHOOLID");
        loading();
        new SelectSchool(schoolid,handler);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
       getListView().setOnCreateContextMenuListener(new View.OnCreateContextMenuListener() {
           @Override
           public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
               if (schoolid == 0|schoolid == 1|schoolid == R.id.shoucang) {
                   menu.add(0,1,0,"删除");
               }else {
                   menu.add(0,0,0,"收藏");
               }
           }
       });
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Job job = jobList.get(position);
        new SelectClickStartWeb((MainActivity) getActivity(),job.getSchoolName(),job.getId());
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
//                得到所点击listview选项的position；
                AdapterView.AdapterContextMenuInfo menuInfo =
                        (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                int position = menuInfo.position;
                Job job = jobList.get(position);
        switch (item.getItemId()){
            case 0:
                Toast.makeText(getActivity(), "收藏成功", Toast.LENGTH_SHORT).show();
                new AddDataToDb(getActivity(),job.getCompanyName(),job.getSitusName(),job.getTime(),job.getId(),job.getSchoolName());
                break;
            case 1:
                Toast.makeText(getActivity(), "删除成功", Toast.LENGTH_SHORT).show();
//                把数据库相应条目删除并刷新当前fragment
                new DeleteDataForDb(getActivity(),job.getId());
               new StartFragment((MainActivity) getActivity(),1);
        }
        return super.onContextItemSelected(item);
    }
    public void loading(){
        if (schoolid != R.id.shoucang&&schoolid != 0) {
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setTitle("请稍等");
            progressDialog.setMessage("正在加载数据");
            progressDialog.setCancelable(true);
            progressDialog.show();
        }
        }
    }
