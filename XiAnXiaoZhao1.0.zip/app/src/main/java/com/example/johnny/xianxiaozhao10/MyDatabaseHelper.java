package com.example.johnny.xianxiaozhao10;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by johnny on 2016/3/5.
 */
public class MyDatabaseHelper extends SQLiteOpenHelper {
    public static final String SCHOOLNAME = "schoolName";
    public static final String TABLENAME = "jobData";
    public static final String COMPANYNAME = "companyName";
    public static final String SITUSNAME = "situsName";
    public static final String TIME = "time";
    public static final String JOBID = "jobId";
    private final String CRATE_JOBDATA = "CREATE TABLE "
            + TABLENAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COMPANYNAME + " TEXT,"
            + SITUSNAME + " TEXT,"
            + TIME + " TEXT,"
            + JOBID + " TEXT,"
            + SCHOOLNAME + " TEXT)" ;
    public MyDatabaseHelper(Context context){
        super(context,"XiAnXiaoZhao.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CRATE_JOBDATA);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
