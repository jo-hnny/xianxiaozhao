package com.example.johnny.xianxiaozhao10;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * Created by johnny on 2016/3/1.
 */
//处理JSON类型的数据
public class ParseJson {
    private String httpData;
    private List<Job> jobList;
    private int schoolId;
    public ParseJson(String jsonData,List<Job> jobList,int schoolId){
        this.httpData = jsonData;
        this.jobList = jobList;
        this.schoolId = schoolId;
        setSchoolName();
    }
    public void setSchoolName(){
        switch (schoolId){
            case R.id.xiankejidaxue:
                parseJson("西安科技大学");
                break;
            case R.id.xianjianzhukejidaxue:
                parseJson("西安建筑科技大学");
                break;
            case R.id.changandaxue:
                parseJson("长安大学");
                break;
            case R.id.xiangongchengdaxue:
                parseJson("西安工程大学");
                break;
            case R.id.xibeinonglinkejidaxue:
                parseJson("西北农林科技大学");
                break;
        }
    }
    public void parseJson(String schoolName){
        try {
            JSONObject jo = new JSONObject(httpData);
            int total = jo.getInt("total");
            JSONArray ja = jo.optJSONArray("rows");
            for (int i = (total-1);i>=0;i--) {
                JSONObject jsonObject = ja.getJSONObject(i);
                String id = jsonObject.getString("Id");
                String companyName = jsonObject.getString("CompanyName");
                String situsName = jsonObject.getString("SitusName");
                String meetData = jsonObject.getString("MeetDate");
                String timesName = jsonObject.getString("TimesName");
                Job job = new Job(companyName,schoolName+situsName,meetData.substring(0,11)+timesName,id,schoolName);
                jobList.add(job);
            }
            }catch (Exception e){
            e.printStackTrace();
        }
    }
}
