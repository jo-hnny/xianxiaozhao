package com.example.johnny.xianxiaozhao10;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by johnny on 2016/3/5.
 */
public class DeleteDataForDb {
    private MyDatabaseHelper dbHelper;
    private Context activity;
    private String id;
    public DeleteDataForDb(Context activity,String id){
        this.activity = activity;
        this.id = id;
        delete();
    }
    public void delete(){
        dbHelper = new MyDatabaseHelper(activity);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(MyDatabaseHelper.TABLENAME,"jobId = ?",new String[]{id});
    }
}
